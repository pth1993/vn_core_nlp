from .vnTokenizer import vnTokenizer
from .JVnSegmenter import JVnSegmenter
