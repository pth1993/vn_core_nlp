from .vnSentDetector import vnSentDetector
