from setuptools import setup


setup(name='vn_core_nlp',
      version='0.1',
      description='The python package for vietnamese text processing',
      author='Hoang Pham',
      author_email='phamthaihoang.hn@gmail.com',
      packages=['vn_core_nlp'],
      zip_safe=False)
